package com.obdjauges.app;

import android.content.Context;

import java.util.Map;

/** Accès public au service OBD pour l'écran Android Auto (paquet .car). */
public final class ObdBridge {
    private ObdBridge() { }

    public static String stateName() { return ObdService.stateName; }

    public static Map<String, Double> latest() { return ObdService.latest; }

    public static void connect(Context c, String address, String name) { ObdService.connectBt(c, address, name); }

    public static void disconnect(Context c) { ObdService.stop(c); }
}
