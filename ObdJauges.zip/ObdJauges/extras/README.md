# Écran Android Auto « Car App Library » (non utilisé)

Ces deux fichiers donnent un vrai écran de jauges Android Auto (GridTemplate).
Android Auto ne l'affiche que si l'appli est installée depuis Google Play
(par exemple via le « Partage interne d'applications », compte développeur à 25 $).
Les applis Car App Library ne sont pas concernées par l'option « Sources inconnues ».

Pour la réactiver : remettre ces fichiers dans app/src/main/java/com/obdjauges/app/car/,
ajouter `implementation 'androidx.car.app:app:1.4.0'` dans app/build.gradle,
et redéclarer le service `.car.ObdCarService` (catégorie androidx.car.app.category.IOT) dans le manifeste.
