package com.obdjauges.app.car;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;

import androidx.car.app.CarContext;
import androidx.car.app.CarToast;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.CarIcon;
import androidx.car.app.model.GridItem;
import androidx.car.app.model.GridTemplate;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.OnClickListener;
import androidx.car.app.model.Template;
import androidx.core.graphics.drawable.IconCompat;
import androidx.lifecycle.Lifecycle;

import com.obdjauges.app.ObdBridge;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Écran Android Auto : 6 jauges (les mêmes que les « grandes jauges » choisies sur le téléphone),
 * rafraîchies chaque seconde. Les titres ne changent pas, donc Android Auto accepte les mises à jour.
 */
public class GaugesScreen extends Screen {

    // clé, libellé, unité, min, max, décimales, seuil d'alerte (NaN = aucun)
    private static final Object[][] CAT = {
            {"boost", "Turbo", "bar", -1.0, 1.8, 2, 1.6},
            {"coolant", "Liquide", "°C", 40.0, 130.0, 0, 112.0},
            {"oil", "Huile", "°C", 40.0, 150.0, 0, 130.0},
            {"rpm", "Régime", "tr/min", 0.0, 7000.0, 0, 6200.0},
            {"iat", "Air admission", "°C", -20.0, 80.0, 0, 60.0},
            {"batt", "Batterie", "V", 10.0, 16.0, 1, Double.NaN},
            {"speed", "Vitesse", "km/h", 0.0, 240.0, 0, Double.NaN},
            {"load", "Charge", "%", 0.0, 100.0, 0, Double.NaN},
            {"throttle", "Papillon", "%", 0.0, 100.0, 0, Double.NaN},
            {"map", "Admission", "kPa", 0.0, 280.0, 0, Double.NaN},
            {"timing", "Avance", "°", -20.0, 50.0, 1, Double.NaN},
            {"maf", "Débit d'air", "g/s", 0.0, 150.0, 1, Double.NaN},
            {"stft", "Corr. court", "%", -25.0, 25.0, 1, Double.NaN},
            {"ltft", "Corr. long", "%", -25.0, 25.0, 1, Double.NaN},
            {"fuelLvl", "Carburant", "%", 0.0, 100.0, 0, Double.NaN},
            {"fuelRail", "Rail", "bar", 0.0, 250.0, 0, Double.NaN},
            {"cat", "Catalyseur", "°C", 0.0, 950.0, 0, Double.NaN},
            {"ambient", "Ext.", "°C", -20.0, 45.0, 0, Double.NaN},
            {"ecuVolt", "Calculateur", "V", 10.0, 16.0, 1, Double.NaN},
            {"fuelRate", "Conso", "L/h", 0.0, 30.0, 1, Double.NaN},
            {"runtime", "Moteur", "s", 0.0, 3600.0, 0, Double.NaN},
            {"baro", "Atmo.", "kPa", 80.0, 110.0, 0, Double.NaN},
    };
    private static final String[] DEFAULT_FAV = {"boost", "coolant", "oil", "rpm", "iat", "batt"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean scheduled = false;

    public GaugesScreen(CarContext carContext) {
        super(carContext);
    }

    @Override
    public Template onGetTemplate() {
        scheduleRefresh();
        boolean connected = "connected".equals(ObdBridge.stateName());
        Map<String, Double> v = ObdBridge.latest();

        ItemList.Builder list = new ItemList.Builder();
        for (String key : favourites()) {
            Object[] c = find(key);
            if (c == null) continue;
            Double val = connected ? v.get(key) : null;
            String txt = format(c, val);
            list.addItem(new GridItem.Builder()
                    .setTitle((String) c[1])                         // titre fixe (règle de rafraîchissement)
                    .setText(txt)
                    .setImage(new CarIcon.Builder(IconCompat.createWithBitmap(drawGauge(c, val))).build(),
                            GridItem.IMAGE_TYPE_LARGE)
                    .build());
        }

        Action connect = new Action.Builder()
                .setTitle(connected ? "Déconnecter" : stateLabel())
                .setOnClickListener(new OnClickListener() {
                    @Override public void onClick() { toggleConnection(); }
                })
                .build();

        return new GridTemplate.Builder()
                .setTitle("Jauges OBD")
                .setHeaderAction(Action.APP_ICON)
                .setSingleList(list.build())
                .setActionStrip(new ActionStrip.Builder().addAction(connect).build())
                .build();
    }

    /* ---------------- rafraîchissement ---------------- */

    private void scheduleRefresh() {
        if (scheduled) return;
        scheduled = true;
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                scheduled = false;
                if (getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) invalidate();
            }
        }, 1000);
    }

    /* ---------------- connexion ---------------- */

    private String stateLabel() {
        String s = ObdBridge.stateName();
        if ("connecting".equals(s)) return "Connexion…";
        if ("error".equals(s)) return "Réessayer";
        return "Connecter";
    }

    private void toggleConnection() {
        CarContext ctx = getCarContext();
        String s = ObdBridge.stateName();
        if ("connected".equals(s) || "connecting".equals(s)) {
            ObdBridge.disconnect(ctx);
            return;
        }
        SharedPreferences p = ctx.getSharedPreferences("obd", Context.MODE_PRIVATE);
        String addr = p.getString("lastAddress", null);
        if (addr == null) {
            CarToast.makeText(ctx, "Connecte-toi une 1re fois depuis l'appli sur le téléphone", CarToast.LENGTH_LONG).show();
            return;
        }
        try {
            ObdBridge.connect(ctx, addr, p.getString("lastName", "ELM327"));
            CarToast.makeText(ctx, "Connexion à l'adaptateur…", CarToast.LENGTH_SHORT).show();
        } catch (Exception e) {
            CarToast.makeText(ctx, "Ouvre Jauges OBD sur le téléphone pour te connecter", CarToast.LENGTH_LONG).show();
        }
    }

    /* ---------------- jauges ---------------- */

    private List<String> favourites() {
        List<String> out = new ArrayList<>();
        try {
            String json = getCarContext().getSharedPreferences("obd", Context.MODE_PRIVATE).getString("fav", null);
            if (json != null) {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length() && out.size() < 6; i++) out.add(a.getString(i));
            }
        } catch (Exception ignored) { }
        if (out.isEmpty()) for (String k : DEFAULT_FAV) out.add(k);
        return out;
    }

    private static Object[] find(String key) {
        for (Object[] c : CAT) if (c[0].equals(key)) return c;
        return null;
    }

    private static String format(Object[] c, Double v) {
        if (v == null) return "—";
        if ("runtime".equals(c[0])) {
            int s = (int) Math.round(v);
            return String.format(Locale.FRANCE, "%d:%02d", s / 60, s % 60);
        }
        int dec = (Integer) c[5];
        String s = String.format(Locale.FRANCE, "%." + dec + "f", v);
        if ("boost".equals(c[0]) && v > 0) s = "+" + s;
        return s + " " + c[2];
    }

    /** Dessine une jauge ronde avec la valeur au centre. */
    private static Bitmap drawGauge(Object[] c, Double v) {
        int size = 256;
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        double min = (Double) c[3], max = (Double) c[4], warn = (Double) c[6];
        float f = v == null ? 0f : (float) Math.max(0, Math.min(1, (v - min) / (max - min)));
        boolean hot = v != null && !Double.isNaN(warn) && v >= warn;
        boolean lowBatt = v != null && "batt".equals(c[0]) && v < 11.8;

        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(22);
        RectF r = new RectF(24, 24, size - 24, size - 24);
        arc.setColor(Color.argb(60, 255, 255, 255));
        cv.drawArc(r, 135, 270, false, arc);
        arc.setColor(hot ? Color.rgb(255, 77, 94) : lowBatt ? Color.rgb(255, 176, 32) : Color.rgb(45, 212, 191));
        if (f > 0.003f) cv.drawArc(r, 135, 270 * f, false, arc);

        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(Color.WHITE);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        String val = v == null ? "—" : format(c, v).replace(" " + c[2], "");
        t.setTextSize(val.length() > 5 ? 54 : 70);
        cv.drawText(val, size / 2f, size / 2f + 22, t);
        t.setTypeface(Typeface.DEFAULT);
        t.setTextSize(28);
        t.setColor(Color.argb(170, 255, 255, 255));
        cv.drawText((String) c[2], size / 2f, size / 2f + 64, t);
        return bmp;
    }
}
