/* Jauges OBD — interface. Événements Android : O.onState(), O.onData(), O.onDtc(), O.onBack(), O.onPermissions() */
(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var A = window.Android;

  /* ---------- catalogue des valeurs (clés identiques à Pids.java) ---------- */
  var CAT = {
    boost:    { l: 'Pression turbo',    u: 'bar',    min: -1,  max: 1.8,  d: 2 },
    coolant:  { l: 'Liquide refroid.',  u: '°C',     min: 40,  max: 130,  d: 0 },
    oil:      { l: 'Huile',             u: '°C',     min: 40,  max: 150,  d: 0 },
    rpm:      { l: 'Régime',            u: 'tr/min', min: 0,   max: 7000, d: 0, warn: 6200 },
    iat:      { l: 'Air admission',     u: '°C',     min: -20, max: 80,   d: 0, warn: 60 },
    batt:     { l: 'Batterie',          u: 'V',      min: 10,  max: 16,   d: 1, low: 11.8 },
    speed:    { l: 'Vitesse',           u: 'km/h',   min: 0,   max: 240,  d: 0 },
    load:     { l: 'Charge moteur',     u: '%',      min: 0,   max: 100,  d: 0 },
    throttle: { l: 'Papillon',          u: '%',      min: 0,   max: 100,  d: 0 },
    map:      { l: 'Pression admission',u: 'kPa',    min: 0,   max: 280,  d: 0 },
    timing:   { l: 'Avance allumage',   u: '°',      min: -20, max: 50,   d: 1 },
    maf:      { l: 'Débit d\'air',      u: 'g/s',    min: 0,   max: 150,  d: 1 },
    stft:     { l: 'Correction court t.', u: '%',    min: -25, max: 25,   d: 1 },
    ltft:     { l: 'Correction long t.',  u: '%',    min: -25, max: 25,   d: 1 },
    fuelLvl:  { l: 'Carburant',         u: '%',      min: 0,   max: 100,  d: 0 },
    fuelRail: { l: 'Pression rail',     u: 'bar',    min: 0,   max: 250,  d: 0 },
    cat:      { l: 'Catalyseur',        u: '°C',     min: 0,   max: 950,  d: 0 },
    ambient:  { l: 'Temp. extérieure',  u: '°C',     min: -20, max: 45,   d: 0 },
    ecuVolt:  { l: 'Tension calculateur', u: 'V',    min: 10,  max: 16,   d: 1 },
    fuelRate: { l: 'Consommation',      u: 'L/h',    min: 0,   max: 30,   d: 1 },
    runtime:  { l: 'Depuis démarrage',  u: '',       min: 0,   max: 3600, d: 0 },
    baro:     { l: 'Pression atmo.',    u: 'kPa',    min: 80,  max: 110,  d: 0 }
  };

  /* ---------- réglages ---------- */
  var KEY = 'obd.cfg.v1';
  var cfg = { fav: ['boost', 'coolant', 'oil', 'rpm', 'iat', 'batt'], tank: 52, warnCoolant: 112, warnOil: 130, warnBoost: 1.6, toLauncher: true };
  try { var saved = JSON.parse(localStorage.getItem(KEY) || '{}'); for (var k in saved) cfg[k] = saved[k]; } catch (e) { }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) { } pushOptions(); }
  function pushOptions() {
    if (!A) return;
    A.setFast(JSON.stringify(cfg.fav));
    A.setOptions(Number(cfg.tank) || 52, !!cfg.toLauncher);
  }
  CAT.coolant.warn = function () { return cfg.warnCoolant; };
  CAT.oil.warn = function () { return cfg.warnOil; };
  CAT.boost.warn = function () { return cfg.warnBoost; };
  function warnOf(k) { var w = CAT[k].warn; return typeof w === 'function' ? w() : w; }

  /* ---------- état ---------- */
  var state = { state: 'idle', supported: [] }, data = {}, peaks = {}, lastAlert = {};
  function supported(k) { return state.state === 'connected' && state.supported.indexOf(k) >= 0; }

  function fmt(k, v) {
    if (v == null || isNaN(v)) return '—';
    if (k === 'runtime') { var m = Math.floor(v / 60), s = Math.round(v % 60); return m + ':' + (s < 10 ? '0' : '') + s; }
    var d = CAT[k].d, s2 = Number(v).toFixed(d);
    if (k === 'boost' && v > 0) s2 = '+' + s2;
    return s2.replace('.', ',');
  }

  /* ---------- jauges rondes (SVG) ---------- */
  var R = 74, CX = 100, CY = 96, L = R * Math.PI * 1.5;
  function pt(a, r) { var t = a * Math.PI / 180; return [CX + r * Math.cos(t), CY + r * Math.sin(t)]; }
  function gaugeSvg(k) {
    var s = pt(135, R), e = pt(45, R), c = CAT[k];
    var arc = 'M' + s[0].toFixed(1) + ' ' + s[1].toFixed(1) + ' A' + R + ' ' + R + ' 0 1 1 ' + e[0].toFixed(1) + ' ' + e[1].toFixed(1);
    return '<svg viewBox="0 0 200 182" preserveAspectRatio="xMidYMid meet">' +
      '<path class="arcbg" d="' + arc + '"/>' +
      '<path class="arc" d="' + arc + '" stroke-dasharray="' + L.toFixed(1) + '" stroke-dashoffset="' + L.toFixed(1) + '"/>' +
      '<line class="peak" x1="0" y1="0" x2="0" y2="0"/>' +
      '<text class="val" x="100" y="104" text-anchor="middle">—</text>' +
      '<text class="unit" x="100" y="124" text-anchor="middle">' + c.u + '</text>' +
      '<text class="mm" x="' + (s[0] + 4).toFixed(0) + '" y="' + (s[1] + 16).toFixed(0) + '" text-anchor="middle">' + c.min + '</text>' +
      '<text class="mm" x="' + (e[0] - 4).toFixed(0) + '" y="' + (e[1] + 16).toFixed(0) + '" text-anchor="middle">' + c.max + '</text>' +
      '<text class="lbl" x="100" y="176" text-anchor="middle">' + c.l + '</text></svg>';
  }

  function buildGauges() {
    var g = $('#bigGrid'); g.innerHTML = '';
    cfg.fav.slice(0, 6).forEach(function (k) {
      var d = document.createElement('div');
      d.className = 'card g'; d.setAttribute('data-k', k);
      d.innerHTML = gaugeSvg(k);
      d.addEventListener('click', function () { delete peaks[k]; render(); toast('Maxi « ' + CAT[k].l + ' » remis à zéro'); });
      g.appendChild(d);
    });
    var sm = $('#smallGrid'); sm.innerHTML = '';
    Object.keys(CAT).forEach(function (k) {
      if (cfg.fav.indexOf(k) >= 0) return;
      var t = document.createElement('div');
      t.className = 'card t'; t.setAttribute('data-k', k);
      t.innerHTML = '<small>' + CAT[k].l + '</small><b>—</b>';
      sm.appendChild(t);
    });
    render();
  }

  function render() {
    var connected = state.state === 'connected';
    $('#emptyMsg').classList.toggle('show', !connected);
    $$('#bigGrid .g').forEach(function (el) {
      var k = el.getAttribute('data-k'), c = CAT[k], v = data[k], sup = supported(k);
      el.classList.toggle('na', connected && !sup);
      var txt = el.querySelector('.val');
      txt.textContent = connected && !sup ? 'n/d' : fmt(k, v);
      el.querySelector('.unit').textContent = connected && !sup ? 'non dispo sur ta voiture' : c.u;
      var f = v == null ? 0 : Math.max(0, Math.min(1, (v - c.min) / (c.max - c.min)));
      el.querySelector('.arc').setAttribute('stroke-dashoffset', (L * (1 - f)).toFixed(1));
      if (v != null && (peaks[k] == null || v > peaks[k])) peaks[k] = v;
      var line = el.querySelector('.peak');
      if (peaks[k] != null && sup) {
        var fp = Math.max(0, Math.min(1, (peaks[k] - c.min) / (c.max - c.min))), a = 135 + 270 * fp, p1 = pt(a, R - 9), p2 = pt(a, R + 9);
        line.style.display = ''; line.setAttribute('x1', p1[0]); line.setAttribute('y1', p1[1]); line.setAttribute('x2', p2[0]); line.setAttribute('y2', p2[1]);
      } else { line.style.display = 'none'; }
      var w = warnOf(k), hot = v != null && w != null && v >= w, low = v != null && c.low != null && v < c.low;
      var alert = hot && (k === 'coolant' || k === 'oil');
      el.classList.toggle('alert', alert);
      el.classList.toggle('warn', (hot || low) && !alert);
      if (alert && (!lastAlert[k] || Date.now() - lastAlert[k] > 60000)) { lastAlert[k] = Date.now(); toast('⚠️ ' + c.l + ' : ' + fmt(k, v) + ' ' + c.u); }
    });
    $$('#smallGrid .t').forEach(function (el) {
      var k = el.getAttribute('data-k');
      el.style.display = connected && !supported(k) ? 'none' : '';
      el.querySelector('b').innerHTML = fmt(k, data[k]) + (CAT[k].u ? '<i>' + CAT[k].u + '</i>' : '');
    });
  }

  /* ---------- connexion ---------- */
  function renderConn() {
    var s = state.state, dot = $('#connDot'), t = $('#connTxt');
    dot.className = 'dot' + (s === 'connected' ? ' ok' : s === 'connecting' ? ' busy' : s === 'error' ? ' err' : '');
    t.textContent = s === 'connected' ? (state.device || 'Connecté') : s === 'connecting' ? (state.message || 'Connexion…') : s === 'error' ? 'Erreur' : 'Non connecté';
    $('#discBtn').style.display = s === 'connected' || s === 'connecting' ? '' : 'none';
    $('#adapterInfo').textContent = state.version ? state.version + ' · protocole ' + (state.protocol || '?') : '—';
    if (s === 'error' && state.message) $('#connHelp').innerHTML = '<b style="color:#ff9aa5">' + esc(state.message) + '</b>';
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function openConn() {
    $('#connSheet').classList.add('show');
    var r = A ? JSON.parse(A.getDevices()) : MOCK.devices();
    var list = $('#devList');
    if (r.error === 'permission') { list.innerHTML = '<span class="muted">Autorise l\'accès Bluetooth (« Appareils à proximité »).</span>'; if (A) A.askPermissions(); return; }
    if (r.error) { list.innerHTML = '<span class="muted">' + esc(r.error) + '</span>'; return; }
    var devs = (r.devices || []).sort(function (a, b) { return (b.obd ? 1 : 0) - (a.obd ? 1 : 0); });
    if (!devs.length) { list.innerHTML = '<span class="muted">Aucun appareil appairé. Touche « Appairer un adaptateur ».</span>'; return; }
    list.innerHTML = '';
    devs.forEach(function (d) {
      var b = document.createElement('button');
      b.className = 'dev' + (d.obd ? ' obd' : '');
      b.innerHTML = '<span><b>' + esc(d.name) + '</b><small>' + esc(d.address) + (d.obd ? ' · adaptateur OBD probable' : '') + '</small></span><span>Connecter ›</span>';
      b.addEventListener('click', function () {
        $('#connHelp').textContent = 'Connexion à ' + d.name + '… (le contact doit être mis)';
        if (A) A.connectBt(d.address, d.name); else MOCK.connect(d.name);
        setTimeout(closeSheet, 600);
      });
      list.appendChild(b);
    });
  }
  function closeSheet() { $('#connSheet').classList.remove('show'); }
  function wifi() {
    var host = prompt('Adresse de l\'ELM327 Wi-Fi', '192.168.0.10'); if (!host) return;
    var port = parseInt(prompt('Port', '35000'), 10) || 35000;
    if (A) A.connectWifi(host, port); else MOCK.connect('ELM327 Wi-Fi');
    closeSheet();
  }

  /* ---------- codes défaut ---------- */
  var clearArmed = false;
  function dtcDesc(c) {
    var t = { P: 'Moteur / boîte', C: 'Châssis', B: 'Carrosserie', U: 'Réseau / communication' }[c[0]] || '';
    return t + (c[1] === '0' || c[1] === '2' ? ' · code générique' : ' · code constructeur');
  }

  /* ---------- API appelée par Android ---------- */
  window.O = {
    onState: function (s) {
      var was = state.state; state = s || { state: 'idle' }; state.supported = state.supported || [];
      if (state.state !== 'connected') data = {};
      if (was !== 'connected' && state.state === 'connected') { peaks = {}; toast('Connecté ✓'); closeSheet(); }
      renderConn(); render(); buildFavs();
    },
    onData: function (d) { data = d || {}; render(); },
    onDtc: function (r) {
      var el = $('#dtcList');
      if (r.error) { el.innerHTML = '<span class="muted">' + esc(r.error) + '</span>'; return; }
      var all = (r.stored || []).map(function (c) { return [c, false]; }).concat((r.pending || []).map(function (c) { return [c, true]; }));
      if (r.cleared) toast('Codes effacés');
      el.innerHTML = all.length ? all.map(function (x) {
        return '<div class="code' + (x[1] ? ' pend' : '') + '"><b>' + esc(x[0]) + '</b><small>' + dtcDesc(x[0]) + '</small><small>' + (x[1] ? 'En attente (pas encore confirmé)' : 'Mémorisé') + '</small></div>';
      }).join('') : '<span class="okmsg">✓ Aucun code défaut</span>';
    },
    onBack: function () {
      if ($('#connSheet').classList.contains('show')) { closeSheet(); return true; }
      if (!$('#tab-gauges').classList.contains('on')) { tab('gauges'); return true; }
      return false;
    },
    onPermissions: function () { if ($('#connSheet').classList.contains('show')) openConn(); }
  };

  /* ---------- réglages ---------- */
  function buildFavs() {
    var el = $('#favList'); el.innerHTML = '';
    Object.keys(CAT).forEach(function (k) {
      var i = cfg.fav.indexOf(k), b = document.createElement('button');
      b.className = 'fav' + (i >= 0 ? ' on' : '') + (state.state === 'connected' && !supported(k) ? ' na' : '');
      b.innerHTML = '<span class="n">' + (i >= 0 ? i + 1 : '') + '</span>' + CAT[k].l;
      b.addEventListener('click', function () {
        var j = cfg.fav.indexOf(k);
        if (j >= 0) cfg.fav.splice(j, 1);
        else if (cfg.fav.length >= 6) { toast('6 grandes jauges maximum'); return; }
        else cfg.fav.push(k);
        save(); buildFavs(); buildGauges();
      });
      el.appendChild(b);
    });
  }
  function bindSettings() {
    ['tank', 'warnCoolant', 'warnOil', 'warnBoost'].forEach(function (id) {
      var i = $('#' + id); i.value = cfg[id];
      i.addEventListener('change', function () { cfg[id] = Number(i.value); save(); render(); });
    });
    var t = $('#toLauncher'); t.classList.toggle('on', cfg.toLauncher);
    t.addEventListener('click', function () { cfg.toLauncher = !cfg.toLauncher; t.classList.toggle('on', cfg.toLauncher); save(); });
  }

  function tab(name) {
    $$('.tab').forEach(function (t) { t.classList.toggle('on', t.getAttribute('data-tab') === name); });
    $$('.tabpage').forEach(function (p) { p.classList.toggle('on', p.id === 'tab-' + name); });
  }
  function toast(m) {
    var t = $('#toast'); t.textContent = m; t.classList.add('show');
    clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove('show'); }, 2400);
  }

  document.addEventListener('click', function (e) {
    var tb = e.target.closest('[data-tab]'); if (tb) { tab(tb.getAttribute('data-tab')); return; }
    var a = e.target.closest('[data-act]'); if (!a) { if (e.target.id === 'connSheet') closeSheet(); return; }
    switch (a.getAttribute('data-act')) {
      case 'conn': case 'refresh': openConn(); break;
      case 'close': closeSheet(); break;
      case 'wifi': wifi(); break;
      case 'disconnect': if (A) A.disconnect(); else MOCK.stop(); closeSheet(); break;
      case 'btsettings': if (A) A.openBtSettings(); else toast('Réglages Bluetooth (simulation)'); break;
      case 'readdtc':
        $('#dtcList').innerHTML = '<span class="muted">Lecture…</span>';
        if (A) A.readDtc(); else MOCK.dtc(false); break;
      case 'cleardtc':
        if (!clearArmed) {
          clearArmed = true; $('#clearBtn').textContent = 'Confirmer l\'effacement';
          toast('Moteur coupé, contact mis. Appuie encore pour confirmer.');
          setTimeout(function () { clearArmed = false; $('#clearBtn').textContent = 'Effacer'; }, 4000);
        } else {
          clearArmed = false; $('#clearBtn').textContent = 'Effacer';
          $('#dtcList').innerHTML = '<span class="muted">Effacement…</span>';
          if (A) A.clearDtc(); else MOCK.dtc(true);
        }
        break;
    }
  });

  /* ---------- simulateur (aperçu sur PC) ---------- */
  var MOCK = {
    timer: 0,
    devices: function () { return { devices: [{ name: 'Téléphone', address: '00:11:22:33:44:55' }, { name: 'OBDII', address: '00:1D:A5:68:98:8B', obd: true }] }; },
    connect: function (name) {
      O.onState({ state: 'connecting', device: name, message: 'Dialogue avec la voiture…' });
      setTimeout(function () {
        O.onState({ state: 'connected', device: name, version: 'ELM327 v1.5', protocol: '6',
          supported: ['load', 'coolant', 'stft', 'ltft', 'map', 'rpm', 'speed', 'timing', 'iat', 'maf', 'throttle', 'runtime', 'fuelLvl', 'baro', 'cat', 'ecuVolt', 'ambient', 'boost', 'batt'] });
        var t0 = Date.now();
        clearInterval(MOCK.timer);
        MOCK.timer = setInterval(function () {
          var s = (Date.now() - t0) / 1000, w = Math.max(0, Math.sin(s / 2.5));
          O.onData({ rpm: 900 + w * 3600, boost: -0.55 + w * 1.45, map: 46 + w * 145, baro: 101, coolant: 91, iat: 24 + w * 6, batt: 14.1, speed: 50 + w * 40,
            load: 20 + w * 70, throttle: 12 + w * 80, timing: 14 - w * 8, maf: 4 + w * 70, stft: 1.6, ltft: -2.3, fuelLvl: 58, cat: 610, ecuVolt: 14.0, ambient: 8, runtime: s + 754 });
        }, 500);
      }, 900);
    },
    stop: function () { clearInterval(MOCK.timer); O.onState({ state: 'idle' }); },
    dtc: function (clear) { setTimeout(function () { O.onDtc(clear ? { cleared: true, stored: [], pending: [] } : { stored: ['P0171', 'P1083'], pending: ['P0300'] }); }, 600); }
  };

  /* ---------- démarrage ---------- */
  buildGauges(); buildFavs(); bindSettings(); pushOptions();
  if (A) O.onState(JSON.parse(A.getState())); else { renderConn(); render(); }
  window.MOCK = MOCK;
})();
