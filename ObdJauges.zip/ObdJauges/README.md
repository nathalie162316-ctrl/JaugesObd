# Jauges OBD — tes valeurs moteur en direct (ELM327)

Appli Android de jauges pour adaptateur **ELM327 Bluetooth** (ou Wi-Fi).
Elle marche sur l'autoradio comme sur un téléphone.

- 6 grandes jauges au choix, avec le maximum atteint : pression turbo, liquide de refroidissement, huile, régime, air d'admission, batterie…
- Toutes les autres valeurs que publie le moteur, en petites cases.
- Alertes : liquide ou huile trop chauds, surpression turbo, batterie faible.
- Lecture et effacement des **codes défaut** (voyant moteur).
- Envoi automatique des valeurs à **Car Launcher** : Ext., Batt., Carbu. et régime de l'accueil.
- La connexion reste active en arrière-plan : une notification « Jauges OBD » s'affiche tant qu'elle tourne.

## Fabriquer l'APK (GitHub, comme pour Car Launcher)

1. Sur GitHub, crée un **nouveau repository** `ObdJauges` en **Private**. N'utilise pas celui de Car Launcher.
2. **uploading an existing file**, puis glisse **tout le contenu** du dossier `ObdJauges`, puis **Commit changes**.
3. Si le dossier `.github` n'est pas passé : onglet **Actions** → **set up a workflow yourself**,
   efface tout, colle le contenu du fichier `.github/workflows/build.yml` (une seule ligne), puis **Commit changes**.
4. **Actions** → attends le ✅ → **Artifacts** → **JaugesOBD-apk**.

## Première connexion

1. Branche l'ELM327 sur la prise OBD (sous le volant, côté gauche) et **mets le contact**.
2. Paramètres Bluetooth de l'autoradio → rechercher → appaire « OBDII », « V-LINK »… (code **1234** ou **0000**).
3. Ouvre **Jauges OBD**, touche **Non connecté** en haut à droite, puis choisis l'adaptateur.

## Bon à savoir

- **Seules les valeurs OBD standard** sont lisibles. Ce que la voiture ne publie pas s'affiche « n/d ».
  Sur beaucoup de BMW, la **température d'huile** n'est pas dans l'OBD standard
  (BimmerLink la lit avec des requêtes propres à BMW).
- La **pression turbo** est calculée : pression d'admission moins pression atmosphérique, en bar relatif.
- **Effacer les codes** éteint le voyant, mais ne répare rien. Si le défaut est toujours là, le code revient.
- Si l'autoradio ne trouve pas l'adaptateur, c'est souvent que son Bluetooth est **propriétaire**
  (réservé au téléphone), ce qui arrive sur certains écrans chinois. Dans ce cas, utilise l'appli sur ton téléphone,
  ou passe à un ELM327 Wi-Fi (bouton « ELM327 Wi-Fi »).
- Ne la regarde pas en roulant : jette un œil à l'arrêt, ou laisse les alertes te prévenir.

## Structure

```
app/src/main/java/com/obdjauges/app/
  Elm327.java      dialogue avec l'adaptateur + décodage (testé avec un faux ELM327)
  Pids.java        liste des valeurs OBD et formules (norme SAE J1979)
  ObdService.java  connexion Bluetooth/Wi-Fi en arrière-plan, envoi à Car Launcher
  MainActivity.java, JsBridge.java   écran + pont avec l'interface
app/src/main/assets/www/   l'interface (ouvre index.html dans Chrome pour un aperçu simulé)
```
