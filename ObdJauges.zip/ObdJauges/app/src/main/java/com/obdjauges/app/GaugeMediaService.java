package com.obdjauges.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.media.MediaMetadata;
import android.media.browse.MediaBrowser;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.media.MediaBrowserService;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Android Auto (catégorie « média ») : les jauges s'affichent comme la pochette d'un « morceau »
 * mise à jour chaque seconde. ▶/⏸ démarre/arrête l'affichage, ⏮/⏭ change de page de valeurs.
 * Cette catégorie est acceptée par Android Auto avec « Sources inconnues » (pas besoin du Play Store).
 * Aucun son n'est joué et la musique (Spotify…) n'est pas coupée.
 */
public class GaugeMediaService extends MediaBrowserService {

    private static final String ROOT = "root", ID_GAUGES = "gauges", ID_CONNECT = "connect";
    private static final String[] DEFAULT_FAV = {"boost", "coolant", "oil", "rpm", "iat", "batt"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaSession session;
    private boolean showing = false;
    private int page = 0;
    private String lastState = "";

    @Override
    public void onCreate() {
        super.onCreate();
        session = new MediaSession(this, "JaugesOBD");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { start(); }
            @Override public void onPause() { stop(); }
            @Override public void onStop() { stop(); }
            @Override public void onSkipToNext() { page++; refresh(); }
            @Override public void onSkipToPrevious() { page = Math.max(0, page - 1); refresh(); }
            @Override public void onPlayFromMediaId(String mediaId, Bundle extras) {
                if (ID_CONNECT.equals(mediaId)) toggleConnection();
                start();
            }
        }, handler);
        setSessionToken(session.getSessionToken());
        setState(PlaybackState.STATE_PAUSED);
        refresh();
        handler.post(watcher);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        session.setActive(false);
        session.release();
        super.onDestroy();
    }

    /* ---------------- arborescence affichée dans Android Auto ---------------- */

    @Override
    public BrowserRoot onGetRoot(String clientPackageName, int clientUid, Bundle rootHints) {
        return new BrowserRoot(ROOT, null);
    }

    @Override
    public void onLoadChildren(String parentId, Result<List<MediaBrowser.MediaItem>> result) {
        List<MediaBrowser.MediaItem> items = new ArrayList<>();
        if (ROOT.equals(parentId)) {
            String st = ObdBridge.stateName();
            items.add(item(ID_GAUGES, "Afficher les jauges", statusText(st)));
            boolean on = "connected".equals(st) || "connecting".equals(st);
            items.add(item(ID_CONNECT, on ? "Déconnecter l'ELM327" : "Connecter l'ELM327",
                    on ? "Arrêter la lecture OBD" : "Utilise le dernier adaptateur choisi sur le téléphone"));
        }
        result.sendResult(items);
    }

    private MediaBrowser.MediaItem item(String id, String title, String sub) {
        MediaDescription d = new MediaDescription.Builder().setMediaId(id).setTitle(title).setSubtitle(sub).build();
        return new MediaBrowser.MediaItem(d, MediaBrowser.MediaItem.FLAG_PLAYABLE);
    }

    /* ---------------- affichage ---------------- */

    private void start() {
        showing = true;
        session.setActive(true);
        setState(PlaybackState.STATE_PLAYING);
        refresh();
    }

    private void stop() {
        showing = false;
        setState(PlaybackState.STATE_PAUSED);
    }

    private void setState(int state) {
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_STOP | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                | PlaybackState.ACTION_PLAY_FROM_MEDIA_ID;
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(state, PlaybackState.PLAYBACK_POSITION_UNKNOWN, state == PlaybackState.STATE_PLAYING ? 1f : 0f)
                .build());
    }

    // toutes les secondes : nouvelle image si l'affichage est actif ; mise à jour de la liste si l'état change
    private final Runnable watcher = new Runnable() {
        @Override public void run() {
            String st = ObdBridge.stateName();
            if (!st.equals(lastState)) { lastState = st; notifyChildrenChanged(ROOT); }
            if (showing) refresh();
            handler.postDelayed(this, 1000);
        }
    };

    private void refresh() {
        String st = ObdBridge.stateName();
        boolean connected = "connected".equals(st);
        Map<String, Double> v = connected ? ObdBridge.latest() : new HashMap<String, Double>();
        List<List<String>> pages = GaugeArt.pages(favourites(), v);
        if (page >= pages.size()) page = pages.size() - 1;
        List<String> keys = pages.get(page);

        StringBuilder title = new StringBuilder(), artist = new StringBuilder();
        for (int i = 0; i < keys.size(); i++) {
            Object[] c = GaugeArt.find(keys.get(i));
            if (c == null) continue;
            String part = c[1] + " " + GaugeArt.withUnit(c, v.get(keys.get(i)));
            StringBuilder sb = i < 2 ? title : artist;
            if (sb.length() > 0) sb.append("  ·  ");
            sb.append(part);
        }
        Bitmap art = GaugeArt.composite(keys, v, statusText(st), page, pages.size());
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_MEDIA_ID, ID_GAUGES)
                .putString(MediaMetadata.METADATA_KEY_TITLE, connected ? title.toString() : "Jauges OBD")
                .putString(MediaMetadata.METADATA_KEY_ARTIST, connected ? artist.toString() : statusText(st))
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "Jauges OBD")
                .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art)
                .putBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON, art)
                .build());
    }

    private static String statusText(String st) {
        if ("connected".equals(st)) return "● Connecté";
        if ("connecting".equals(st)) return "Connexion à l'adaptateur…";
        if ("error".equals(st)) return "Erreur de connexion — réessaie";
        return "Non connecté";
    }

    /* ---------------- connexion ---------------- */

    private void toggleConnection() {
        String st = ObdBridge.stateName();
        if ("connected".equals(st) || "connecting".equals(st)) { ObdBridge.disconnect(this); return; }
        SharedPreferences p = getSharedPreferences("obd", Context.MODE_PRIVATE);
        String addr = p.getString("lastAddress", null);
        if (addr == null) return;   // jamais connecté depuis le téléphone
        try { ObdBridge.connect(this, addr, p.getString("lastName", "ELM327")); } catch (Exception ignored) { }
    }

    private List<String> favourites() {
        List<String> out = new ArrayList<>();
        try {
            String json = getSharedPreferences("obd", Context.MODE_PRIVATE).getString("fav", null);
            if (json != null) {
                JSONArray a = new JSONArray(json);
                for (int i = 0; i < a.length() && out.size() < 6; i++) out.add(a.getString(i));
            }
        } catch (Exception ignored) { }
        if (out.isEmpty()) for (String k : DEFAULT_FAV) out.add(k);
        return out;
    }
}
