package com.obdjauges.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Écran des jauges : WebView plein écran (assets/www) reliée au service OBD. */
public class MainActivity extends Activity implements ObdService.Listener {

    private static final int REQ_PERMS = 21;
    WebView web;
    private boolean ready = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideBars();
        web = new WebView(this);
        web.setBackgroundColor(0xFF0A0F2C);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new JsBridge(this), "Android");
        web.setWebChromeClient(new WebChromeClient());   // nécessaire pour les fenêtres de saisie (Wi-Fi)
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                ready = true;
                onState(ObdService.state());
            }
        });
        web.loadUrl("file:///android_asset/www/index.html");
        ObdService.listener = this;
        askPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ObdService.listener = this;
        hideBars();
        if (ready) onState(ObdService.state());
    }

    @Override
    protected void onDestroy() {
        if (ObdService.listener == this) ObdService.listener = null;   // le service continue tout seul
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web != null && ready) web.evaluateJavascript("window.O&&O.onBack()", null);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @SuppressWarnings("deprecation")
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    /* ---------------- permissions ---------------- */

    void askPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED)
            need.add("android.permission.BLUETOOTH_CONNECT");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            need.add("android.permission.POST_NOTIFICATIONS");
        if (Build.VERSION.SDK_INT < 31 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);      // requis pour le Bluetooth sur les anciens Android
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission("android.permission.BLUETOOTH_CONNECT") == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        js("O.onPermissions()");
    }

    /* ---------------- événements du service -> page ---------------- */

    void js(final String call) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (web != null && ready) web.evaluateJavascript("window.O&&" + call, null);
            }
        });
    }

    @Override public void onState(String json) { js("O.onState(" + safe(json) + ")"); }
    @Override public void onData(String json) { js("O.onData(" + safe(json) + ")"); }
    @Override public void onDtc(String json) { js("O.onDtc(" + safe(json) + ")"); }

    private static String safe(String json) {
        try { new JSONObject(json); return json; } catch (Exception e) { return "{}"; }
    }
}
