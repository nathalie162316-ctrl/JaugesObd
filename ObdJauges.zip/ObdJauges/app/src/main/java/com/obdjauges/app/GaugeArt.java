package com.obdjauges.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Dessin des jauges en image (pour Android Auto) + mise en forme des valeurs. */
final class GaugeArt {

    private GaugeArt() { }

    // clé, libellé, unité, min, max, décimales, seuil d'alerte (NaN = aucun)
    static final Object[][] CAT = {
            {"boost", "Turbo", "bar", -1.0, 1.8, 2, 1.6},
            {"coolant", "Liquide", "°C", 40.0, 130.0, 0, 112.0},
            {"oil", "Huile", "°C", 40.0, 150.0, 0, 130.0},
            {"rpm", "Régime", "tr/min", 0.0, 7000.0, 0, 6200.0},
            {"iat", "Air adm.", "°C", -20.0, 80.0, 0, 60.0},
            {"batt", "Batterie", "V", 10.0, 16.0, 1, Double.NaN},
            {"speed", "Vitesse", "km/h", 0.0, 240.0, 0, Double.NaN},
            {"load", "Charge", "%", 0.0, 100.0, 0, Double.NaN},
            {"throttle", "Papillon", "%", 0.0, 100.0, 0, Double.NaN},
            {"map", "Admission", "kPa", 0.0, 280.0, 0, Double.NaN},
            {"timing", "Avance", "°", -20.0, 50.0, 1, Double.NaN},
            {"maf", "Débit air", "g/s", 0.0, 150.0, 1, Double.NaN},
            {"stft", "Corr. court", "%", -25.0, 25.0, 1, Double.NaN},
            {"ltft", "Corr. long", "%", -25.0, 25.0, 1, Double.NaN},
            {"fuelLvl", "Carburant", "%", 0.0, 100.0, 0, Double.NaN},
            {"fuelRail", "Rail", "bar", 0.0, 250.0, 0, Double.NaN},
            {"cat", "Catalyseur", "°C", 0.0, 950.0, 0, Double.NaN},
            {"ambient", "Ext.", "°C", -20.0, 45.0, 0, Double.NaN},
            {"ecuVolt", "Calculateur", "V", 10.0, 16.0, 1, Double.NaN},
            {"fuelRate", "Conso", "L/h", 0.0, 30.0, 1, Double.NaN},
            {"runtime", "Moteur", "", 0.0, 3600.0, 0, Double.NaN},
            {"baro", "Atmo.", "kPa", 80.0, 110.0, 0, Double.NaN},
    };

    static Object[] find(String key) {
        for (Object[] c : CAT) if (c[0].equals(key)) return c;
        return null;
    }

    static String value(Object[] c, Double v) {
        if (v == null) return "—";
        if ("runtime".equals(c[0])) {
            int s = (int) Math.round(v);
            return String.format(Locale.FRANCE, "%d:%02d", s / 60, s % 60);
        }
        String s = String.format(Locale.FRANCE, "%." + c[5] + "f", v);
        if ("boost".equals(c[0]) && v > 0) s = "+" + s;
        return s;
    }

    static String withUnit(Object[] c, Double v) {
        String u = (String) c[2];
        return v == null || u.isEmpty() ? value(c, v) : value(c, v) + " " + u;
    }

    /** Pages de 6 valeurs : d'abord les favoris, puis les autres valeurs disponibles. */
    static List<List<String>> pages(List<String> fav, Map<String, Double> values) {
        List<List<String>> out = new ArrayList<>();
        out.add(new ArrayList<>(fav));
        List<String> rest = new ArrayList<>();
        for (Object[] c : CAT) {
            String k = (String) c[0];
            if (!fav.contains(k) && values.containsKey(k)) rest.add(k);
        }
        for (int i = 0; i < rest.size(); i += 6) out.add(new ArrayList<>(rest.subList(i, Math.min(rest.size(), i + 6))));
        return out;
    }

    /** Image carrée avec jusqu'à 6 jauges (3 colonnes × 2 lignes) et une ligne d'état. */
    static Bitmap composite(List<String> keys, Map<String, Double> v, String status, int page, int pageCount) {
        int W = 720;
        Bitmap bmp = Bitmap.createBitmap(W, W, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        cv.drawColor(Color.rgb(10, 15, 44));

        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTextAlign(Paint.Align.CENTER);
        t.setColor(Color.argb(200, 255, 255, 255));
        t.setTextSize(30);
        cv.drawText(status + (pageCount > 1 ? "   ·   page " + (page + 1) + "/" + pageCount : ""), W / 2f, 52, t);

        int cols = 3, top = 80, cellW = W / cols, cellH = (W - top) / 2;
        for (int i = 0; i < keys.size() && i < 6; i++) {
            Object[] c = find(keys.get(i));
            if (c == null) continue;
            float x = (i % cols) * cellW, y = top + (i / cols) * cellH;
            drawGauge(cv, x, y, cellW, cellH, c, v.get(keys.get(i)));
        }
        return bmp;
    }

    private static void drawGauge(Canvas cv, float x, float y, float w, float h, Object[] c, Double v) {
        double min = (Double) c[3], max = (Double) c[4], warn = (Double) c[6];
        float f = v == null ? 0f : (float) Math.max(0, Math.min(1, (v - min) / (max - min)));
        boolean hot = v != null && !Double.isNaN(warn) && v >= warn;
        boolean low = v != null && "batt".equals(c[0]) && v < 11.8;

        float r = Math.min(w, h - 50) / 2f - 18, cx = x + w / 2f, cy = y + 16 + r + 8;
        RectF rect = new RectF(cx - r, cy - r, cx + r, cy + r);
        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(16);
        arc.setColor(Color.argb(55, 255, 255, 255));
        cv.drawArc(rect, 135, 270, false, arc);
        arc.setColor(hot ? Color.rgb(255, 77, 94) : low ? Color.rgb(255, 176, 32) : Color.rgb(45, 212, 191));
        if (f > 0.003f) cv.drawArc(rect, 135, 270 * f, false, arc);

        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTextAlign(Paint.Align.CENTER);
        t.setColor(Color.WHITE);
        t.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        String val = value(c, v);
        t.setTextSize(val.length() > 5 ? 40 : 52);
        cv.drawText(val, cx, cy + 14, t);
        t.setTypeface(Typeface.DEFAULT);
        t.setTextSize(22);
        t.setColor(Color.argb(170, 255, 255, 255));
        cv.drawText((String) c[2], cx, cy + 46, t);
        t.setTextSize(26);
        t.setColor(Color.argb(230, 255, 255, 255));
        cv.drawText((String) c[1], cx, cy + r + 30, t);
    }
}
