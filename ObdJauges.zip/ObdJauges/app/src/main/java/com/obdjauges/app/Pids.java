package com.obdjauges.app;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Valeurs OBD-II standard (mode 01) et leurs formules (norme SAE J1979).
 * Ne dépend pas d'Android.
 */
final class Pids {

    private Pids() { }

    /** clé utilisée par l'interface -> numéro de PID */
    static final Map<String, Integer> KEYS = new LinkedHashMap<>();
    static {
        KEYS.put("load", 0x04);
        KEYS.put("coolant", 0x05);
        KEYS.put("stft", 0x06);
        KEYS.put("ltft", 0x07);
        KEYS.put("map", 0x0B);
        KEYS.put("rpm", 0x0C);
        KEYS.put("speed", 0x0D);
        KEYS.put("timing", 0x0E);
        KEYS.put("iat", 0x0F);
        KEYS.put("maf", 0x10);
        KEYS.put("throttle", 0x11);
        KEYS.put("runtime", 0x1F);
        KEYS.put("fuelRail", 0x23);
        KEYS.put("fuelLvl", 0x2F);
        KEYS.put("baro", 0x33);
        KEYS.put("cat", 0x3C);
        KEYS.put("ecuVolt", 0x42);
        KEYS.put("ambient", 0x46);
        KEYS.put("oil", 0x5C);
        KEYS.put("fuelRate", 0x5E);
    }

    static String keyOf(int pid) {
        for (Map.Entry<String, Integer> e : KEYS.entrySet()) if (e.getValue() == pid) return e.getKey();
        return null;
    }

    /** Convertit les octets reçus en valeur physique, ou null si la réponse est trop courte. */
    static Double compute(int pid, int[] d) {
        if (d == null || d.length < 1) return null;
        int a = d[0], b = d.length > 1 ? d[1] : -1;
        switch (pid) {
            case 0x04: case 0x11: case 0x2F: return a * 100.0 / 255;           // %
            case 0x05: case 0x0F: case 0x46: case 0x5C: return a - 40.0;       // °C
            case 0x06: case 0x07: return (a - 128) * 100.0 / 128;              // %
            case 0x0B: case 0x33: case 0x0D: return (double) a;                // kPa / km/h
            case 0x0E: return a / 2.0 - 64;                                    // °
            case 0x0C: return b < 0 ? null : (256 * a + b) / 4.0;              // tr/min
            case 0x10: return b < 0 ? null : (256 * a + b) / 100.0;            // g/s
            case 0x1F: return b < 0 ? null : (double) (256 * a + b);           // s
            case 0x23: return b < 0 ? null : (256 * a + b) * 10.0 / 100.0;     // bar (10 kPa/bit)
            case 0x3C: return b < 0 ? null : (256 * a + b) / 10.0 - 40;        // °C
            case 0x42: return b < 0 ? null : (256 * a + b) / 1000.0;           // V
            case 0x5E: return b < 0 ? null : (256 * a + b) / 20.0;             // L/h
            default: return null;
        }
    }
}
