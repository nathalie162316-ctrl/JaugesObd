package com.obdjauges.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Closeable;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Service de premier plan : garde la connexion avec l'ELM327 même quand on quitte l'appli
 * (les valeurs continuent d'alimenter Car Launcher).
 */
public class ObdService extends Service {

    static final String ACTION_BT = "bt", ACTION_WIFI = "wifi", ACTION_STOP = "stop";
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String CHANNEL = "obd";
    private static final String LAUNCHER_PKG = "com.carlauncher.app";
    private static final String LAUNCHER_ACTION = "com.carlauncher.app.CAN_DATA";

    /** Écouteur (l'écran de l'appli) ; null quand l'écran est fermé. */
    interface Listener {
        void onState(String json);
        void onData(String json);
        void onDtc(String json);
    }

    static volatile Listener listener;
    static volatile ObdService instance;

    // réglages envoyés par l'interface
    static volatile Set<String> fastKeys = new HashSet<>();
    static volatile double tankLiters = 52;
    static volatile boolean sendToLauncher = true;

    private static volatile String stateJson = "{\"state\":\"idle\"}";

    private final ConcurrentLinkedQueue<Runnable> tasks = new ConcurrentLinkedQueue<>();
    private volatile boolean running;
    private Thread worker;
    private Closeable link;
    private Elm327 elm;
    private final Map<String, Double> values = new ConcurrentHashMap<>();
    private volatile int gen = 0;            // n° de connexion (ignore les anciens threads)
    private Set<Integer> supported = new HashSet<>();
    private long lastLauncher = 0;

    /* ---------------- commandes depuis l'interface ---------------- */

    static void connectBt(Context c, String address, String name) {
        Intent i = new Intent(c, ObdService.class).setAction(ACTION_BT).putExtra("address", address).putExtra("name", name);
        start(c, i);
    }

    static void connectWifi(Context c, String host, int port) {
        Intent i = new Intent(c, ObdService.class).setAction(ACTION_WIFI).putExtra("host", host).putExtra("port", port);
        start(c, i);
    }

    static void stop(Context c) {
        ObdService s = instance;
        if (s != null) s.shutdown("idle", null, null);
    }

    static String state() { return stateJson; }

    static void requestDtc(final boolean clear) {
        final ObdService s = instance;
        if (s == null || s.elm == null) {
            Listener l = listener;
            if (l != null) l.onDtc("{\"error\":\"Pas connecté\"}");
            return;
        }
        s.tasks.add(new Runnable() {
            @Override public void run() { s.doDtc(clear); }
        });
    }

    private static void start(Context c, Intent i) {
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    /* ---------------- cycle de vie du service ---------------- */

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        instance = this;
        goForeground("Connexion…");
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            shutdown("idle", null, null);
            return START_NOT_STICKY;
        }
        final Intent it = intent;
        stopWorker();
        running = true;
        final int myGen = ++gen;
        worker = new Thread(new Runnable() {
            @Override public void run() { loop(it, myGen); }
        }, "obd");
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        closeLink();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    private void goForeground(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Connexion OBD", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int piFlags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        b.setContentTitle("Jauges OBD").setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setOngoing(true)
                .setContentIntent(PendingIntent.getActivity(this, 0, open, piFlags));
        Notification n = b.build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
            else startForeground(1, n);
        } catch (Exception e) {
            try { startForeground(1, n); } catch (Exception ignored) { }
        }
    }

    /* ---------------- boucle principale ---------------- */

    private boolean alive(int myGen) { return running && myGen == gen; }

    private void loop(Intent it, int myGen) {
        String label = it.getStringExtra("name");
        try {
            setState("connecting", label, "Connexion à l'adaptateur…");
            if (ACTION_WIFI.equals(it.getAction())) openWifi(it.getStringExtra("host"), it.getIntExtra("port", 35000));
            else openBt(it.getStringExtra("address"));
            if (label == null) label = "ELM327 Wi-Fi";
            setState("connecting", label, "Dialogue avec la voiture…");
            elm.init();
            supported = elm.supported();
            setState("connected", label, null);
            goForeground("Connecté à " + label);
        } catch (Exception e) {
            if (alive(myGen)) shutdown("error", label, e.getMessage() == null ? "Échec de connexion" : e.getMessage());
            return;
        }

        int cycle = 0, fails = 0;
        while (alive(myGen)) {
            Runnable t;
            while ((t = tasks.poll()) != null) t.run();
            try {
                boolean slow = cycle % 6 == 0;
                List<Integer> todo = new ArrayList<>();
                Set<String> fast = fastKeys;
                for (Map.Entry<String, Integer> e : Pids.KEYS.entrySet()) {
                    int pid = e.getValue();
                    if (!supported.contains(pid)) continue;
                    boolean isFast = fast.contains(e.getKey())
                            || (fast.contains("boost") && (pid == 0x0B))
                            || pid == 0x0C;                                  // régime toujours rapide
                    if (pid == 0x33 && cycle % 30 != 0) continue;            // pression atmo : rarement
                    if (isFast || slow) todo.add(pid);
                }
                int ok = 0;
                for (int pid : todo) {
                    if (!alive(myGen)) break;
                    Double v = Pids.compute(pid, elm.query(pid));
                    if (v != null) { values.put(Pids.keyOf(pid), v); ok++; }
                }
                if (slow) {
                    Double rv = elm.batteryVoltage();
                    if (rv != null) values.put("batt", rv);
                }
                Double map = values.get("map");
                if (map != null) {
                    Double baro = values.get("baro");
                    values.put("boost", (map - (baro != null ? baro : 101.3)) / 100.0);   // bar relatif
                }
                fails = (ok == 0 && !todo.isEmpty()) ? fails + 1 : 0;
                if (fails > 10) throw new IOException("La voiture ne répond plus (contact coupé ?)");
                pushData();
                cycle++;
            } catch (IOException e) {
                if (alive(myGen)) shutdown("error", label, e.getMessage());
                return;
            }
        }
    }

    private void doDtc(boolean clear) {
        Listener l = listener;
        try {
            JSONObject o = new JSONObject();
            if (clear) o.put("cleared", elm.clearDtc());
            JSONArray stored = new JSONArray(), pending = new JSONArray();
            for (String c : elm.readDtc(false)) stored.put(c);
            for (String c : elm.readDtc(true)) pending.put(c);
            o.put("stored", stored);
            o.put("pending", pending);
            if (l != null) l.onDtc(o.toString());
        } catch (Exception e) {
            if (l != null) l.onDtc("{\"error\":" + JSONObject.quote(String.valueOf(e.getMessage())) + "}");
        }
    }

    /* ---------------- liaison Bluetooth / Wi-Fi ---------------- */

    @SuppressLint("MissingPermission")
    private void openBt(String address) throws Exception {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) throw new IOException("Pas de Bluetooth Android sur cet appareil.");
        if (!ad.isEnabled()) throw new IOException("Active le Bluetooth.");
        BluetoothDevice dev = ad.getRemoteDevice(address);
        try { ad.cancelDiscovery(); } catch (Exception ignored) { }
        BluetoothSocket s;
        try {
            s = dev.createRfcommSocketToServiceRecord(SPP);
            s.connect();
        } catch (IOException e1) {
            try {
                s = dev.createInsecureRfcommSocketToServiceRecord(SPP);
                s.connect();
            } catch (IOException e2) {
                // contournement classique pour les clones ELM327 bon marché
                Method m = dev.getClass().getMethod("createRfcommSocket", int.class);
                s = (BluetoothSocket) m.invoke(dev, 1);
                try { s.connect(); }
                catch (IOException e3) { throw new IOException("Impossible de joindre l'adaptateur. Il est bien branché, contact mis, et appairé ?"); }
            }
        }
        link = s;
        elm = new Elm327(s.getInputStream(), s.getOutputStream());
    }

    private void openWifi(String host, int port) throws IOException {
        Socket s = new Socket();
        s.connect(new InetSocketAddress(host, port), 5000);
        s.setTcpNoDelay(true);
        link = s;
        elm = new Elm327(s.getInputStream(), s.getOutputStream());
    }

    private void closeLink() {
        try { if (link != null) link.close(); } catch (Exception ignored) { }
        link = null;
        elm = null;
    }

    private void stopWorker() {
        running = false;
        closeLink();
        if (worker != null) { try { worker.join(1500); } catch (InterruptedException ignored) { } }
        worker = null;
        values.clear();
    }

    private void shutdown(String st, String label, String msg) {
        running = false;
        closeLink();
        setState(st, label, msg);
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        stopSelf();
    }

    /* ---------------- envoi des données ---------------- */

    private void setState(String st, String label, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("state", st);
            if (label != null) o.put("device", label);
            if (msg != null) o.put("message", msg);
            if (elm != null) { o.put("version", elm.version); o.put("protocol", elm.protocol); }
            JSONArray sup = new JSONArray();
            for (int pid : supported) { String k = Pids.keyOf(pid); if (k != null) sup.put(k); }
            if (supported.contains(0x0B)) sup.put("boost");
            sup.put("batt");
            o.put("supported", sup);
            stateJson = o.toString();
        } catch (Exception ignored) { }
        Listener l = listener;
        if (l != null) l.onState(stateJson);
    }

    private void pushData() {
        JSONObject o = new JSONObject();
        try { for (Map.Entry<String, Double> e : values.entrySet()) o.put(e.getKey(), e.getValue()); } catch (Exception ignored) { }
        Listener l = listener;
        if (l != null) l.onData(o.toString());

        long now = System.currentTimeMillis();
        if (sendToLauncher && now - lastLauncher > 1000) {
            lastLauncher = now;
            Intent i = new Intent(LAUNCHER_ACTION).setPackage(LAUNCHER_PKG);
            put(i, "coolant", "coolant");
            put(i, "rpm", "rpm");
            put(i, "speed", "speed");
            put(i, "ambient", "temp_ext");
            if (values.containsKey("batt")) put(i, "batt", "batt_v"); else put(i, "ecuVolt", "batt_v");
            Double lvl = values.get("fuelLvl");
            if (lvl != null) i.putExtra("fuel_l", lvl * tankLiters / 100.0);
            try { sendBroadcast(i); } catch (Exception ignored) { }
        }
    }

    private void put(Intent i, String key, String extra) {
        Double v = values.get(key);
        if (v != null) i.putExtra(extra, v);
    }
}
