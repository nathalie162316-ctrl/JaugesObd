package com.obdjauges.app.car;

import android.content.Intent;

import androidx.car.app.CarAppService;
import androidx.car.app.Screen;
import androidx.car.app.Session;
import androidx.car.app.validation.HostValidator;

/** Point d'entrée Android Auto : Android Auto se connecte à ce service pour afficher les jauges. */
public class ObdCarService extends CarAppService {

    @Override
    public HostValidator createHostValidator() {
        // appli personnelle installée hors Play Store : on accepte tous les hôtes
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @Override
    public Session onCreateSession() {
        return new Session() {
            @Override
            public Screen onCreateScreen(Intent intent) {
                return new GaugesScreen(getCarContext());
            }
        };
    }
}
