package com.obdjauges.app;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Dialogue avec un adaptateur ELM327 (Bluetooth ou Wi-Fi) : commandes AT + requêtes OBD-II.
 * Ne dépend pas d'Android (testable sur PC).
 */
class Elm327 {

    private final InputStream in;
    private final OutputStream out;
    String protocol = "";      // numéro de protocole OBD (ATDPN), ex. "6" = CAN 11 bits 500 kb/s
    String version = "";       // ex. "ELM327 v1.5"

    Elm327(InputStream in, OutputStream out) {
        this.in = in;
        this.out = out;
    }

    /** Envoie une commande et lit la réponse jusqu'au prompt « > ». */
    synchronized String cmd(String c, long timeoutMs) throws IOException {
        while (in.available() > 0) in.read();              // vide ce qui traîne
        out.write((c + "\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        StringBuilder sb = new StringBuilder();
        long end = System.currentTimeMillis() + timeoutMs;
        while (true) {
            if (in.available() > 0) {
                int b = in.read();
                if (b < 0) throw new IOException("Connexion fermée");
                if (b == '>') break;
                sb.append((char) b);
            } else {
                if (System.currentTimeMillis() > end) break;
                try { Thread.sleep(4); } catch (InterruptedException e) { throw new IOException("interrompu"); }
            }
        }
        return sb.toString().replace("\u0000", "").trim();
    }

    /** Initialise l'adaptateur et le dialogue avec la voiture. Lève une exception claire en cas d'échec. */
    void init() throws IOException {
        version = clean(cmd("ATZ", 4000));                 // reset
        cmd("ATE0", 1000);                                 // pas d'écho
        cmd("ATL0", 1000);                                 // pas de saut de ligne
        cmd("ATS0", 1000);                                 // pas d'espaces
        cmd("ATH0", 1000);                                 // pas d'en-têtes
        cmd("ATAT1", 1000);                                // délais adaptatifs
        cmd("ATSP0", 1000);                                // protocole automatique
        String r = cmd("0100", 12000).toUpperCase();       // recherche du protocole
        if (r.contains("UNABLE") || r.contains("NODATA") || r.contains("NO DATA") || r.contains("ERROR") || parse(r, 0x00) == null) {
            throw new IOException("La voiture ne répond pas. Mets le contact (ou démarre le moteur) puis réessaie.");
        }
        protocol = clean(cmd("ATDPN", 1000)).replace("A", "");
    }

    boolean isCan() {
        try { int p = Integer.parseInt(protocol.trim(), 16); return p >= 6 && p <= 9; }
        catch (Exception e) { return true; }
    }

    /** Liste des PID mode 01 supportés par le moteur. */
    Set<Integer> supported() throws IOException {
        Set<Integer> s = new LinkedHashSet<>();
        for (int base = 0x00; base <= 0xA0; base += 0x20) {
            int[] d = query(base);
            if (d == null || d.length < 4) break;
            long bits = ((long) d[0] << 24) | (d[1] << 16) | (d[2] << 8) | d[3];
            for (int i = 0; i < 32; i++) if ((bits & (1L << (31 - i))) != 0) s.add(base + i + 1);
            if (!s.contains(base + 0x20)) break;
        }
        return s;
    }

    /** Requête mode 01 ; renvoie les octets de données ou null. */
    int[] query(int pid) throws IOException {
        return parse(cmd(String.format("01%02X", pid), 1500), pid);
    }

    /** Tension batterie lue directement par l'adaptateur (broche 16 de la prise OBD). */
    Double batteryVoltage() throws IOException {
        String r = clean(cmd("ATRV", 1000)).replace("V", "").replace(",", ".");
        try { return Double.parseDouble(r); } catch (Exception e) { return null; }
    }

    /** Codes défaut : mode 03 (mémorisés) et 07 (en attente). */
    List<String> readDtc(boolean pending) throws IOException {
        return parseDtc(cmd(pending ? "07" : "03", 5000), pending ? 0x47 : 0x43, isCan());
    }

    /** Efface les codes défaut et éteint le voyant moteur (mode 04). */
    boolean clearDtc() throws IOException {
        return cmd("04", 5000).replace(" ", "").toUpperCase().contains("44");
    }

    /* ----------------- décodage (statique, testable) ----------------- */

    static String clean(String s) {
        return s == null ? "" : s.replace("\r", " ").replace("\n", " ").trim();
    }

    /** Extrait les octets de la réponse « 41 PID xx xx … » pour un PID donné. */
    static int[] parse(String resp, int pid) {
        if (resp == null) return null;
        String want = String.format("41%02X", pid);
        for (String line : resp.toUpperCase().split("[\\r\\n]+")) {
            String l = line.replaceAll("\\s", "").replace("SEARCHING...", "");
            l = l.replaceFirst("^[0-9A-F]:", "");          // trame multiple « 0: … »
            int i = l.indexOf(want);
            if (i < 0) continue;
            String hex = l.substring(i + want.length()).replaceAll("[^0-9A-F]", "");
            int n = hex.length() / 2;
            if (n == 0) continue;
            int[] d = new int[n];
            for (int k = 0; k < n; k++) d[k] = Integer.parseInt(hex.substring(2 * k, 2 * k + 2), 16);
            return d;
        }
        return null;
    }

    static List<String> parseDtc(String resp, int header, boolean can) {
        List<String> out = new ArrayList<>();
        if (resp == null) return out;
        String h = String.format("%02X", header);
        String[] lines = resp.toUpperCase().split("[\\r\\n]+");
        if (can) {
            StringBuilder all = new StringBuilder();
            for (String line : lines) {
                String l = line.replaceAll("\\s", "").replace("SEARCHING...", "");
                if (l.matches("^[0-9A-F]{3}$")) continue;   // longueur d'une réponse multi-trames
                l = l.replaceFirst("^[0-9A-F]:", "");
                all.append(l);
            }
            String s = all.toString();
            int i = s.indexOf(h);
            if (i < 0) return out;
            s = s.substring(i + 2);
            if (s.length() < 2) return out;
            int count = Integer.parseInt(s.substring(0, 2), 16);
            s = s.substring(2);
            for (int k = 0; k < count && s.length() >= 4 * (k + 1); k++) add(out, s.substring(4 * k, 4 * k + 4));
        } else {
            for (String line : lines) {
                String l = line.replaceAll("\\s", "");
                if (!l.startsWith(h)) continue;
                l = l.substring(2);
                for (int k = 0; k + 4 <= l.length(); k += 4) add(out, l.substring(k, k + 4));
            }
        }
        return out;
    }

    private static void add(List<String> out, String four) {
        if (!four.matches("[0-9A-F]{4}") || four.equals("0000")) return;
        int b1 = Integer.parseInt(four.substring(0, 2), 16);
        String code = "PCBU".charAt(b1 >> 6) + Integer.toString((b1 >> 4) & 3) + Integer.toHexString(b1 & 0xF).toUpperCase() + four.substring(2);
        if (!out.contains(code)) out.add(code);
    }
}
