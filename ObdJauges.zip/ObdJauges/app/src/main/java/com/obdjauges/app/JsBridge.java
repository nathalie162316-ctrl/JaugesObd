package com.obdjauges.app;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Fonctions appelées par la page (nom JavaScript : « Android »). */
public class JsBridge {

    private final MainActivity a;

    JsBridge(MainActivity activity) { a = activity; }

    /** Adaptateurs Bluetooth déjà appairés (l'ELM327 doit être appairé dans les réglages Android). */
    @SuppressLint("MissingPermission")
    @JavascriptInterface
    public String getDevices() {
        JSONObject o = new JSONObject();
        try {
            JSONArray list = new JSONArray();
            BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
            if (ad == null) o.put("error", "Pas de Bluetooth Android sur cet appareil");
            else if (!a.hasBtPermission()) o.put("error", "permission");
            else if (!ad.isEnabled()) o.put("error", "Bluetooth désactivé");
            else {
                for (BluetoothDevice d : ad.getBondedDevices()) {
                    JSONObject x = new JSONObject();
                    String n = d.getName();
                    x.put("name", n == null ? d.getAddress() : n);
                    x.put("address", d.getAddress());
                    x.put("obd", n != null && n.toUpperCase().matches(".*(OBD|ELM|VLINK|V-LINK|VGATE|ICAR|KONNWEI|VEEPEAK|327).*"));
                    list.put(x);
                }
            }
            o.put("devices", list);
        } catch (Exception e) {
            try { o.put("error", String.valueOf(e.getMessage())); } catch (Exception ignored) { }
        }
        return o.toString();
    }

    @JavascriptInterface
    public void connectBt(String address, String name) { ObdService.connectBt(a, address, name); }

    @JavascriptInterface
    public void connectWifi(String host, int port) { ObdService.connectWifi(a, host, port); }

    @JavascriptInterface
    public void disconnect() { ObdService.stop(a); }

    @JavascriptInterface
    public String getState() { return ObdService.state(); }

    /** Clés interrogées en priorité (jauges affichées en grand). */
    @JavascriptInterface
    public void setFast(String jsonArray) {
        Set<String> s = new HashSet<>();
        try { JSONArray arr = new JSONArray(jsonArray); for (int i = 0; i < arr.length(); i++) s.add(arr.getString(i)); }
        catch (Exception ignored) { }
        ObdService.fastKeys = s;
    }

    @JavascriptInterface
    public void setOptions(double tankLiters, boolean toLauncher) {
        ObdService.tankLiters = tankLiters > 0 ? tankLiters : 52;
        ObdService.sendToLauncher = toLauncher;
    }

    @JavascriptInterface
    public void readDtc() { ObdService.requestDtc(false); }

    @JavascriptInterface
    public void clearDtc() { ObdService.requestDtc(true); }

    @JavascriptInterface
    public void openBtSettings() {
        try { a.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void askPermissions() {
        a.runOnUiThread(new Runnable() { @Override public void run() { a.askPermissions(); } });
    }

    @JavascriptInterface
    public void toast(final String msg) {
        a.runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(a, msg, Toast.LENGTH_SHORT).show(); }
        });
    }
}
